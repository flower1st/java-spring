/***************************************************************************
 * Copyright 2016 by HomeDirect - All rights reserved.                *    
 **************************************************************************/
package com.webstore.app.service;

import java.util.Properties;

import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

public class SendmailService {
}
